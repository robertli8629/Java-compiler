package compiler488.ast.decl;

/**
 * Holds the declaration part of an array.
 */
public class ArrayDeclPart extends DeclarationPart {

	/* The lower and upper boundaries of the array. */
    private Integer lb1, ub1, lb2, ub2;
	private Boolean isTwoDimensional = false ;

	/* The number of objects the array holds. */
	private Integer size;

	public ArrayDeclPart() { }

	public ArrayDeclPart(Integer ub1) {
		this(new Integer(1), ub1);
	}

	public ArrayDeclPart(Integer lb1, Integer ub1) {
		this(lb1, ub1, null, null);
	}

	public ArrayDeclPart(Integer lb1, Integer ub1, Integer lb2, Integer ub2) {
		this.lb1 = lb1;
		this.ub1 = ub1;
		this.lb2 = lb2;
		this.ub2 = ub2;

		if (this.lb2 != null && this.ub2 != null) {
			isTwoDimensional = true;
		}
	}
	
	public Boolean isTwoDimensional() {
		return this.isTwoDimensional;
	}

	/**
	 * Returns a string that describes the array.
	 */
	@Override
	public String toString() {
		return name + "[" + lb1 + ".." + ub1 +
		( isTwoDimensional ?  "," + lb2 + ".." + ub2 : "" )
		+ "]";
	}

	public Integer getSize() {
		return size;
	}

	public Integer getLowerBoundary1() {
		return lb1;
	}

	public Integer getUpperBoundary1() {
		return ub1;
	}

    public void setLowerBoundary1(Integer lb1) {
		this.lb1 = lb1;
	}

    public void setUpperBoundary1(Integer ub1) {
		this.ub1 = ub1;
	}

	public Integer getLowerBoundary2() {
		assert isTwoDimensional ;	// check for misuse
		return lb2;
	}

	public Integer getUpperBoundary2() {
		assert isTwoDimensional ;       // check for misuse
		return ub2;
	}

    public void setLowerBoundary2(Integer lb2) {
        this.isTwoDimensional = true ;
		this.lb2 = lb2;
	}

    public void setUpperBoundary2(Integer ub2) {
	    this.isTwoDimensional = true ;
		this.ub2 = ub2 ;
	}

	public void setSize(Integer size) {
		this.size = size;
	}
	
	public int calculate_array_size() {
	    if (isTwoDimensional) { //2D
		return (ub1 - lb1 + 1) * (ub2 - lb2 + 1);
	    } else { // 1D
		return ub1 - lb1 + 1;
	    }
	}
}
